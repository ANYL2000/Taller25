<?php
require_once '../assets/conexion/servidor.php';
$conexion = connect($host, $port, $db_name, $db_username, $db_password);

$tallerista_seleccionado = $_GET["tallerista"];
$taller_seleccionado = $_GET["taller"];
$calendario_seleccionado = $_GET['calendario'];
$turno_seleccionado = $_GET['turno'];
$dia_seleccionado = $_GET['dia'];

date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');



if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 
}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 

}else if($mes>12||$mes<1){

  echo "<script>alert('Configure correctamente su zona horaria');</script>";
  echo "<script>window.location='alumno1.php';</script>";
}

if($calendario_seleccionado!=$año){
  echo "<script>window.location='alumno1.php';</script>";
}

$con=mysqli_connect($host,$db_username,$db_password,$db_name);
$con->query("SET NAMES 'utf8'");
$validar_talleres = "SELECT * FROM mostrar_talleres WHERE Calendario = '$calendario_seleccionado' AND 
NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
Dia = '$dia_seleccionado'";

$fila_talleres = mysqli_query($con,$validar_talleres);

if(mysqli_num_rows($fila_talleres)==0){
  echo "<script type='text/javascript'>
  window.location='alumno1.php'
  </script>";
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Talleres</title>
   
</header>


<link rel="stylesheet" href="../assets/css/estilo_alumno1.1.css">
<!--<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<?php include 'header_alumno.php'; ?>


</head>
<body>
    


<div class="fondo">

<a class="btn btn-primary taller" href="alumno1.php">Elegir otro taller</a>

<h1 class="titulo_taller">Taller seleccionado</h1>
<div class="taller_informacion">
<p id="subtitulo">  TALLERISTA: <p class="subtitulo_informacion"><?php echo "$tallerista_seleccionado"?></p> </p>
<p id="subtitulo">  TALLER: <p class="subtitulo_informacion"><?php echo "$taller_seleccionado"?></p> </p>
<p id="subtitulo">  CALENDARIO: <p class="subtitulo_informacion"> <?php echo "$calendario_seleccionado"?></p></p>
<p id="subtitulo">  TURNO: <p class="subtitulo_informacion"> <?php echo "$turno_seleccionado "?></p></p>
<p id="subtitulo">  DIA: <p class="subtitulo_informacion"> <?php echo " $dia_seleccionado" ?></p></p>
</div>


<script>
function validar(frm) {
  frm.buscar.disabled = true;
  //for (i=0; i<3; i++)
  if(frm['codigo'].value.length >=8){
    if (frm['codigo'].value ==''  ) return
  frm.buscar.disabled = false;
  }
}
</script>




<button type="button"  class="btn btn-primary" id="consultar" name ="consultar" data-toggle="modal" data-target="#suscribeModal"><img src="../assets/img/anadir.png" alt="../assets/img/anadir.png" >Registrarme</button>
                   
               


</div>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../assets/js/sweetalert.js"></script>

<!--Seccion del modal de la informacion de la persona-->

<!-- Modal -->
<div class="modal fade" id="suscribeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Información del estudiante</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="" method="POST">
        <div class="form-group">
          <!--onclick="buscar_ahora($('#codigo').val());"      onkeyup = "validar(this.form)"-->
        <input type="text" class="form-control" id="codigo" name="codigo" onkeyup = "validar(this.form)" autocomplete="off" autofocus placeholder="Escribe tu Codigo">
            <button type="button" class="btn btn-primary" id="buscar" name="buscar"  disabled>Verificar mis datos</button>   </div>
           
            <div id="datos_buscador">
         
          </div>
         
        </form>
      </div>
      </div>
  </div>
</div>
     



<?php
if(isset($_POST['inscribir'])){

 

  $codigo = $_POST['codigo'];

  $correo = $_POST['correo'];

 if(!empty($correo)){
  
if(filter_var($correo, FILTER_VALIDATE_EMAIL)){

  $consulta_existencia = "SELECT * FROM personas WHERE codigo= '$codigo'";
  
  $usuario_repetido = "SELECT * FROM usuarios_talleres WHERE Codigo= '$codigo' AND Ingreso = '$calendario_seleccionado' AND 
  NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
  Dia = '$dia_seleccionado'";

  $validar_numero_registro = "SELECT * FROM usuarios_talleres WHERE Codigo='$codigo' AND Ingreso = '$calendario_seleccionado'";
  $numero_registros = mysqli_query($con,$validar_numero_registro);


  $validar_fechas_registro = "SELECT * FROM usuarios_talleres WHERE Codigo='$codigo' AND Ingreso = '$calendario_seleccionado' AND Turno='$turno_seleccionado' AND 
  Dia = '$dia_seleccionado'";
  $fechas_registros = mysqli_query($con,$validar_fechas_registro);


  $esta_registrado = mysqli_query($con,$usuario_repetido);

  $filas = mysqli_query($con,$consulta_existencia);

 
  if(mysqli_num_rows($esta_registrado)==0){
  if(mysqli_num_rows($numero_registros)<=1){
  
    if(mysqli_num_rows($fechas_registros)==0){

  
  
  if(mysqli_num_rows($filas)==0){
  
    echo '<script>alertaeNoti("No estás en el sistema")</script>';
  
  }else{

    
    $lugares_talleres = "SELECT * FROM mostrar_talleres WHERE Calendario = '$calendario_seleccionado' AND 
    NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
    Dia = '$dia_seleccionado'";

$filas_talleres = mysqli_query($con,$lugares_talleres);

while($informacion_taller = mysqli_fetch_array($filas_talleres)){
  $registrados = $informacion_taller['Registrados'];
  $faltantes = $informacion_taller['Lugares_Faltantes'];
}

    while($informacion_persona = mysqli_fetch_array($filas)){

     $nombre = $informacion_persona['nombre'];

     $carrera = $informacion_persona['carrera'];

    }

    if($faltantes>=1){
      $conexion->query("SET NAMES 'utf8'");


    $conexion->query("INSERT INTO usuarios_talleres (Codigo,Nombre,Correo,Carrera,Nombretallerista,NombreTaller,Ingreso,Turno,Dia) values ('$codigo','$nombre','$correo','$carrera','$tallerista_seleccionado','$taller_seleccionado','$calendario_seleccionado','$turno_seleccionado','$dia_seleccionado')");

    if($conexion){

      $regitrado_mas = $registrados+1;
      $faltantes_menos = $faltantes-1;

      

      $conexion->query("UPDATE mostrar_talleres SET Registrados= $regitrado_mas, Lugares_Faltantes = $faltantes_menos WHERE Calendario = '$calendario_seleccionado' AND 
  NombreTaller = '$taller_seleccionado' AND NombreTallerista = '$tallerista_seleccionado' AND Turno= '$turno_seleccionado' AND 
  Dia = '$dia_seleccionado'");



    echo '<script>alertaNoti("Se ha inscrito con exito")</script>';
    }
  }else{
    echo '<script>alertaeNoti("Ya no hay lugares para este taller")</script>';
  }
  }


}else{
  echo '<script>alertaeNoti("No debe registrar talleres con el mismo turno y dia")</script>';
}

  }else{
echo '<script>alertaeNoti("Nomás se debe registrar maximo 2 talleres por semestre")</script>';
  } 

}else{
  echo '<script>alertaeNoti("Ya estas registrado en este Taller")</script>';

}

}else{
  echo '<script>alertaeNoti("Correo no válido")</script>';
}
 }else{
  echo '<script>alertaeNoti("No escribiste tu correo")</script>';

 }

}

/*validar correo electronico mediante expresion regular
function is_valid_email($str)
{
  $matches = null;
  return (1 === preg_match('/^[A-z0-9\\._-]+@+^[A-z0-9\\._-]+.+^[A-z0-9\\._-]$/', $str, $matches));
}*/
?>
     
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="../assets/js/jquery-3.6.0.min.js"></script> 
<script src="../assets/js/Buscar.js"></script>
</body>
</html>
<?php $con->close(); $conexion=null; ?>