<?php
require_once '../assets/conexion/servidor.php';

$conexion = mysqli_connect($host, $db_username, $db_password,$db_name );


$validar_cuenta_remitente = "SELECT Correo,(cast(aes_decrypt(Contra,'CUALTOS1234567890') as char))  FROM correo_remitente";


$fila_cuenta_remitente = mysqli_query($conexion,$validar_cuenta_remitente);


$fila = mysqli_fetch_array($fila_cuenta_remitente);



 /* while($cuenta = mysqli_fetch_array($fila_cuenta_remitente)){
    
   
$result = mysql_query("SELECT Max(id) FROM `alumno`;");
$row = mysql_fetch_array($result);
$max = $row[0];
    
  }*/

  
  print_r($fila[0]);
    echo '<br>';
   
  
     print_r($fila[1]);


  

?>